@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1

:: ============================================================
::  ClarityOS — One-click installer for Windows
::  Right-click → Run as Administrator  (only needed once)
:: ============================================================

set "TRACKER_DIR=%~dp0"
if "%TRACKER_DIR:~-1%"=="\" set "TRACKER_DIR=%TRACKER_DIR:~0,-1%"

:: ── Check if running from a temp/zip folder ──────────────────
echo %TRACKER_DIR% | findstr /I /C:"\Temp\" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo  [ERROR] You are running install.bat from inside a ZIP file or temp folder.
    echo.
    echo  Please EXTRACT the zip first:
    echo    1. Right-click ClarityOS-Tracker.zip ^> Extract All
    echo    2. Open the extracted folder
    echo    3. Double-click install.bat
    echo.
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo   ClarityOS Desktop Tracker — Setup
echo   clarityos.kvantumtech.com
echo  ============================================================
echo.

:: ── Step 1: Auto-elevate to admin (no right-click needed) ──────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [INFO] Requesting administrator access — a UAC prompt will appear...
    echo  Please click YES on the security dialog.
    timeout /t 2 /nobreak >nul
    powershell -NoProfile -Command "Start-Process cmd.exe -ArgumentList '/c ""%~f0""' -Verb RunAs"
    exit /b
)

:: ── Step 2: Get API Token via PowerShell GUI dialog ──────────
echo  [1/5] Opening token dialog...

:: Show a proper Windows input dialog — no terminal needed
for /f "delims=" %%T in ('powershell -NoProfile -Command ^
    "Add-Type -AssemblyName Microsoft.VisualBasic; ^
     $t = [Microsoft.VisualBasic.Interaction]::InputBox( ^
       'Paste your ClarityOS API Token below.' + [char]10 + [char]10 + ^
       '  1. Go to clarityos.kvantumtech.com' + [char]10 + ^
       '  2. Sign in with Google' + [char]10 + ^
       '  3. Copy your API Token from the dashboard sidebar' + [char]10 + [char]10 + ^
       'You only need to do this once.', ^
       'ClarityOS — Enter API Token', ''); $t"') do set "USER_TOKEN=%%T"

:: Trim whitespace
set "USER_TOKEN=!USER_TOKEN: =!"

if "!USER_TOKEN!"=="" (
    echo.
    echo  [WARN] No token entered. Tracker will run locally but NOT sync to your dashboard.
    echo         Re-run install.bat at any time to add your token.
    echo.
) else (
    echo  [OK] Token received.
)

:: ── Step 3: Write config.json ────────────────────────────────
echo.
echo  [2/5] Saving configuration...
(
    echo {
    echo   "api_token": "!USER_TOKEN!",
    echo   "api_endpoint": "https://clarityos.kvantumtech.com/api/sync"
    echo }
) > "%TRACKER_DIR%\config.json"
echo  [OK] Config saved to config.json  ^(token stored securely, never shared^)

:: ── Step 4: Python venv + dependencies ───────────────────────
echo.
echo  [3/5] Setting up Python environment...
if not exist "%TRACKER_DIR%\venv\Scripts\pythonw.exe" (
    echo  [INFO] Creating virtual environment...
    python -m venv "%TRACKER_DIR%\venv"
    if %errorlevel% neq 0 (
        powershell -NoProfile -Command ^
            "Add-Type -AssemblyName System.Windows.Forms; ^
             [System.Windows.Forms.MessageBox]::Show( ^
             'Python not found. Please install Python 3.10+ from python.org' + [char]10 + 'Make sure to check ✅ Add Python to PATH during install.', ^
             'ClarityOS — Python Required', ^
             'OK', 'Error')"
        exit /b 1
    )
)
"%TRACKER_DIR%\venv\Scripts\pip.exe" install -q -r "%TRACKER_DIR%\requirements.txt"
echo  [OK] Python environment ready.

:: ── Step 5: Write run_hidden.vbs launcher ────────────────────
echo.
echo  [4/5] Writing silent launcher...
(
    echo Set WshShell = CreateObject^("WScript.Shell"^)
    echo WshShell.Run Chr^(34^) ^& "%TRACKER_DIR%\venv\Scripts\pythonw.exe" ^& Chr^(34^) ^& " " ^& Chr^(34^) ^& "%TRACKER_DIR%\main.py" ^& Chr^(34^), 0
    echo Set WshShell = Nothing
) > "%TRACKER_DIR%\run_hidden.vbs"
echo  [OK] Launcher written.

:: ── Step 6: Register Windows Task Scheduler ──────────────────
echo.
echo  [5/5] Registering auto-start with Windows...
set "TASK_XML=%TEMP%\clarityos_task.xml"
(
    echo ^<?xml version="1.0" encoding="UTF-16"?^>
    echo ^<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"^>
    echo   ^<RegistrationInfo^>
    echo     ^<Description^>ClarityOS — AI Work Tracker, runs silently at login^</Description^>
    echo     ^<Author^>ClarityOS^</Author^>
    echo   ^</RegistrationInfo^>
    echo   ^<Triggers^>
    echo     ^<LogonTrigger^>
    echo       ^<Enabled^>true^</Enabled^>
    echo       ^<Delay^>PT30S^</Delay^>
    echo     ^</LogonTrigger^>
    echo   ^</Triggers^>
    echo   ^<Principals^>
    echo     ^<Principal id="Author"^>
    echo       ^<LogonType^>InteractiveToken^</LogonType^>
    echo       ^<RunLevel^>LeastPrivilege^</RunLevel^>
    echo     ^</Principal^>
    echo   ^</Principals^>
    echo   ^<Settings^>
    echo     ^<MultipleInstancesPolicy^>IgnoreNew^</MultipleInstancesPolicy^>
    echo     ^<DisallowStartIfOnBatteries^>false^</DisallowStartIfOnBatteries^>
    echo     ^<StopIfGoingOnBatteries^>false^</StopIfGoingOnBatteries^>
    echo     ^<ExecutionTimeLimit^>PT0S^</ExecutionTimeLimit^>
    echo     ^<Priority^>7^</Priority^>
    echo   ^</Settings^>
    echo   ^<Actions Context="Author"^>
    echo     ^<Exec^>
    echo       ^<Command^>wscript.exe^</Command^>
    echo       ^<Arguments^>"!TRACKER_DIR!\run_hidden.vbs"^</Arguments^>
    echo       ^<WorkingDirectory^>!TRACKER_DIR!^</WorkingDirectory^>
    echo     ^</Exec^>
    echo   ^</Actions^>
    echo ^</Task^>
) > "%TASK_XML%"

schtasks /Create /XML "%TASK_XML%" /TN "ClarityOS Tracker" /F >nul 2>&1
if %errorlevel% neq 0 (
    echo  [WARN] Could not register auto-start. You can run the tracker manually.
) else (
    echo  [OK] ClarityOS will auto-start silently on every Windows login.
)

:: ── Start tracker now ────────────────────────────────────────
echo.
echo  Starting ClarityOS tracker now...
wscript.exe "%TRACKER_DIR%\run_hidden.vbs"
echo  [OK] Tracker is running silently in the background.

:: ── Open dashboard in browser ────────────────────────────────
echo.
echo  Opening your ClarityOS dashboard...
start "" "https://clarityos.kvantumtech.com"

:: ── Done! ────────────────────────────────────────────────────
echo.
echo  ============================================================
echo   Setup complete! ClarityOS is now:
echo.
echo    ✓ Running silently in the background
echo    ✓ Syncing to your dashboard every 15 minutes
echo    ✓ Set to auto-start on every Windows login
echo.
echo   Dashboard: https://clarityos.kvantumtech.com
echo   To stop:   run stop.bat
echo  ============================================================
echo.
pause
