@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1

:: ============================================================
::  ClarityOS — One-click installer for Windows
::  Double-click to run. UAC prompt will appear automatically.
:: ============================================================

set "TRACKER_DIR=%~dp0"
if "%TRACKER_DIR:~-1%"=="\" set "TRACKER_DIR=%TRACKER_DIR:~0,-1%"

:: ── Detect if running from temp/zip folder ─────────────────
echo %TRACKER_DIR% | findstr /I /C:"\Temp\" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo  [ERROR] Extract the zip first before running install.bat
    echo.
    echo  Steps:
    echo    1. Right-click ClarityOS-Tracker.zip and choose "Extract All"
    echo    2. Open the extracted ClarityOS-Tracker folder
    echo    3. Double-click install.bat
    echo.
    pause
    exit /b 1
)

:: ── Self-elevate to admin without requiring right-click ─────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  Requesting administrator access...
    echo  A Windows security prompt will appear - please click YES.
    echo.
    timeout /t 3 /nobreak >nul
    powershell -NoProfile -WindowStyle Hidden -Command ^
        "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: ============================================================
:: Past here = running as Admin
:: ============================================================

echo.
echo  ============================================================
echo   ClarityOS Desktop Tracker -- Setup
echo   clarityos.kvantumtech.com
echo  ============================================================
echo.
echo  [Admin] Running with administrator privileges. Good.
echo.

:: ── Step 1: Get API Token ────────────────────────────────────
echo  [1/5] Getting your API token...
echo.

set "TOKEN_FILE=%TEMP%\clarityos_token.txt"
del "%TOKEN_FILE%" 2>nul

:: Try GUI dialog first — writes token to temp file
powershell -NoProfile -Command ^
    "Add-Type -AssemblyName Microsoft.VisualBasic; ^
     $t = [Microsoft.VisualBasic.Interaction]::InputBox( ^
       'Paste your ClarityOS API Token below.' + [char]10 + [char]10 + ^
       'Find it at: clarityos.kvantumtech.com' + [char]10 + ^
       '  Sign in with Google then copy the token from your dashboard sidebar.', ^
       'ClarityOS Setup - API Token', ''); ^
     if ($t) { Set-Content -Path '%TOKEN_FILE%' -Value $t -NoNewline }"

:: Read token from file
if exist "%TOKEN_FILE%" (
    set /p USER_TOKEN=<"%TOKEN_FILE%"
    del "%TOKEN_FILE%" 2>nul
)

:: Fallback: if GUI failed or no token entered, ask in console
if "!USER_TOKEN!"=="" (
    echo  Could not show GUI dialog. Please paste your token below:
    echo  ^(Find it at clarityos.kvantumtech.com ^> Dashboard sidebar^)
    echo.
    set /p USER_TOKEN=  Token: 
)

:: Final check
if "!USER_TOKEN!"=="" (
    echo.
    echo  [WARN] No token entered. Tracker will run locally only.
    echo         Re-run install.bat anytime to add your token.
    echo.
) else (
    echo.
    echo  [OK] API token received.
)

:: ── Step 2: Write config.json ────────────────────────────────
echo.
echo  [2/5] Saving configuration...
(
    echo {
    echo   "api_token": "!USER_TOKEN!",
    echo   "api_endpoint": "https://clarityos.kvantumtech.com/api/sync"
    echo }
) > "%TRACKER_DIR%\config.json"
echo  [OK] Config saved.

:: ── Step 3: Python venv + dependencies ──────────────────────
echo.
echo  [3/5] Setting up Python environment (this may take 1-2 minutes)...

:: Check Python exists
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Python not found!
    echo.
    echo  Please install Python 3.10+ from python.org
    echo  During install, check the box: "Add Python to PATH"
    echo  Then re-run install.bat
    echo.
    pause
    exit /b 1
)

if not exist "%TRACKER_DIR%\venv\Scripts\pythonw.exe" (
    echo  Creating virtual environment...
    python -m venv "%TRACKER_DIR%\venv"
    if %errorlevel% neq 0 (
        echo.
        echo  [ERROR] Failed to create virtual environment.
        echo  Make sure Python 3.10+ is installed from python.org
        echo.
        pause
        exit /b 1
    )
)

echo  Installing dependencies...
"%TRACKER_DIR%\venv\Scripts\pip.exe" install -q -r "%TRACKER_DIR%\requirements.txt"
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Failed to install dependencies.
    echo  Check your internet connection and try again.
    echo.
    pause
    exit /b 1
)
echo  [OK] Python environment ready.

:: ── Step 4: Write run_hidden.vbs launcher ───────────────────
echo.
echo  [4/5] Writing silent launcher...
(
    echo Set WshShell = CreateObject^("WScript.Shell"^)
    echo WshShell.Run Chr^(34^) ^& "%TRACKER_DIR%\venv\Scripts\pythonw.exe" ^& Chr^(34^) ^& " " ^& Chr^(34^) ^& "%TRACKER_DIR%\main.py" ^& Chr^(34^), 0
    echo Set WshShell = Nothing
) > "%TRACKER_DIR%\run_hidden.vbs"
echo  [OK] Launcher ready.

:: ── Step 5: Register auto-start with Windows Task Scheduler ─
echo.
echo  [5/5] Registering auto-start with Windows...
set "TASK_XML=%TEMP%\clarityos_task.xml"
(
    echo ^<?xml version="1.0" encoding="UTF-16"?^>
    echo ^<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"^>
    echo   ^<RegistrationInfo^>
    echo     ^<Description^>ClarityOS AI Work Tracker^</Description^>
    echo     ^<Author^>ClarityOS^</Author^>
    echo   ^</RegistrationInfo^>
    echo   ^<Triggers^>
    echo     ^<LogonTrigger^>
    echo       ^<Enabled^>true^</Enabled^>
    echo       ^<Delay^>PT30S^</Delay^>
    echo     ^</LogonTrigger^>
    echo   ^</Triggers^>
    echo   ^<Principals^>
    echo     ^<Principal id="Author"^>
    echo       ^<LogonType^>InteractiveToken^</LogonType^>
    echo       ^<RunLevel^>LeastPrivilege^</RunLevel^>
    echo     ^</Principal^>
    echo   ^</Principals^>
    echo   ^<Settings^>
    echo     ^<MultipleInstancesPolicy^>IgnoreNew^</MultipleInstancesPolicy^>
    echo     ^<DisallowStartIfOnBatteries^>false^</DisallowStartIfOnBatteries^>
    echo     ^<StopIfGoingOnBatteries^>false^</StopIfGoingOnBatteries^>
    echo     ^<ExecutionTimeLimit^>PT0S^</ExecutionTimeLimit^>
    echo     ^<Priority^>7^</Priority^>
    echo   ^</Settings^>
    echo   ^<Actions Context="Author"^>
    echo     ^<Exec^>
    echo       ^<Command^>wscript.exe^</Command^>
    echo       ^<Arguments^>"!TRACKER_DIR!\run_hidden.vbs"^</Arguments^>
    echo       ^<WorkingDirectory^>!TRACKER_DIR!^</WorkingDirectory^>
    echo     ^</Exec^>
    echo   ^</Actions^>
    echo ^</Task^>
) > "%TASK_XML%"

schtasks /Create /XML "%TASK_XML%" /TN "ClarityOS Tracker" /F >nul 2>&1
if %errorlevel% neq 0 (
    echo  [WARN] Could not register auto-start. You can start manually via run_hidden.vbs
) else (
    echo  [OK] ClarityOS will auto-start silently on every Windows login.
)

:: ── Start tracker now ────────────────────────────────────────
echo.
echo  Starting ClarityOS tracker now...
wscript.exe "%TRACKER_DIR%\run_hidden.vbs"
echo  [OK] Tracker is running silently in the background.

:: ── Open dashboard ───────────────────────────────────────────
echo.
echo  Opening your ClarityOS dashboard...
start "" "https://clarityos.kvantumtech.com"

:: ── Done! ────────────────────────────────────────────────────
echo.
echo  ============================================================
echo   Setup complete!
echo.
echo    Tracker is running silently in the background
echo    Auto-starts on every Windows login
echo    Syncs to your dashboard every 15 minutes
echo.
echo   Dashboard: https://clarityos.kvantumtech.com
echo   To stop:   run stop.bat
echo  ============================================================
echo.
pause
