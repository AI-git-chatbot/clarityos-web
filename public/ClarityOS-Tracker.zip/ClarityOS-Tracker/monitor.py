import time
import datetime
import win32gui
import win32process
import win32api
import psutil
from database import log_activity

# Configuration
POLL_INTERVAL = 2.0  # seconds
IDLE_THRESHOLD = 180.0  # 3 minutes without input = idle

def get_idle_time():
    """Returns the time in seconds since the last user input (mouse/keyboard)."""
    last_input = win32api.GetLastInputInfo()
    current_tick = win32api.GetTickCount()
    return (current_tick - last_input) / 1000.0

def get_active_window_info():
    """Returns the executable name and window title of the foreground window."""
    try:
        window = win32gui.GetForegroundWindow()
        title = win32gui.GetWindowText(window)
        _, pid = win32process.GetWindowThreadProcessId(window)
        
        # If no process found (e.g. desktop), return None
        if not pid:
            return "Unknown", title
            
        process = psutil.Process(pid)
        app_name = process.name()
        return app_name, title
    except Exception as e:
        return "Unknown", "Unknown"

def sanitize_title(title):
    """Strip out highly sensitive or noise data from titles if needed."""
    # We can expand this later.
    return title.strip()

def run_tracker():
    """Main loop checking for activity changes."""
    print("Starting AI Work Tracker Monitor...")
    
    current_app = None
    current_title = None
    start_time = datetime.datetime.now()
    
    while True:
        try:
            time.sleep(POLL_INTERVAL)
            
            idle_time = get_idle_time()
            is_idle = idle_time > IDLE_THRESHOLD
            
            app_name, raw_title = get_active_window_info()
            title = sanitize_title(raw_title)
            
            # Use a generic name if idle, or just log the current app as idle
            if is_idle:
                app_name = "Idle"
                title = "System Idle"
            
            # If window changed or idle state changed, log the previous chunk
            if app_name != current_app or title != current_title:
                if current_app is not None:
                    end_time = datetime.datetime.now()
                    duration = (end_time - start_time).total_seconds()
                    
                    # Only log if duration is meaningful (e.g., > 1 sec) to avoid alt-tab spam
                    if duration >= 1.0:
                        is_was_idle = (current_app == "Idle")
                        log_activity(
                            start_time=start_time,
                            end_time=end_time,
                            duration_seconds=int(duration),
                            app_name=current_app,
                            window_title=current_title,
                            is_idle=is_was_idle
                        )
                        print(f"Logged: {current_app} - {current_title} [{int(duration)}s]")
                    
                # Reset tracking for the new active window
                current_app = app_name
                current_title = title
                start_time = datetime.datetime.now()
                
        except KeyboardInterrupt:
            print("\nStopping tracker.")
            break
        except Exception as e:
            print(f"Error in tracker loop: {e}")
            time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    run_tracker()
