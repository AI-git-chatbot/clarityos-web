import threading
import time
import schedule

# Local module imports
from database import init_db
from monitor import run_tracker
from aggregator import aggregate_sessions
from mailer import generate_and_send_report
from datetime import datetime
from app import app as flask_app
import logging

def job_aggregator():
    try:
        aggregate_sessions()
    except Exception as e:
        print(f"[{datetime.now()}] Aggregator error: {e}")

def job_mailer():
    try:
        generate_and_send_report()
    except Exception as e:
        print(f"[{datetime.now()}] Mailer error: {e}")

def run_scheduler_loop():
    print("Starting Background Scheduler Thread...")
    
    # 1. Run the aggregator every 15 minutes to process chunks and call AI
    schedule.every(15).minutes.do(job_aggregator)
    
    # 2. Daily summary email at 2:00 AM
    schedule.every().day.at("02:00").do(job_mailer)
    
    while True:
        try:
            schedule.run_pending()
            time.sleep(60) # Sleep 1 minute between checks to save CPU
        except Exception as e:
            print(f"Scheduler loop error: {e}")
            time.sleep(60)

def run_flask_server():
    # Disable default Flask request logging to keep the console clean for the tracker
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
    
    flask_app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False)

def main():
    print("Initializing AI Work Tracker System...")
    init_db()
    
    # Run the dashboard web server in a background thread
    flask_thread = threading.Thread(target=run_flask_server, daemon=True)
    flask_thread.start()
    
    # Run the scheduler in a dedicated background daemon thread
    scheduler_thread = threading.Thread(target=run_scheduler_loop, daemon=True)
    scheduler_thread.start()
    
    # Run the active window tracker in the main thread
    # This loop runs forever and catches exceptions internally
    try:
        run_tracker()
    except KeyboardInterrupt:
        print("Shutting down AI Work Tracker...")

if __name__ == "__main__":
    main()
