import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "clarityos_tracker.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Category Mappings
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS category_mapping (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        keyword TEXT UNIQUE NOT NULL,
        project_tag TEXT,
        category TEXT
    )""")
    
    # Raw Activities (Window/App tracking)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS raw_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        start_time DATETIME NOT NULL,
        end_time DATETIME NOT NULL,
        duration_seconds INTEGER NOT NULL,
        app_name TEXT NOT NULL,
        window_title TEXT NOT NULL,
        is_idle BOOLEAN DEFAULT 0
    )""")
    # Add indexes silently if they don't exist
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_raw_time ON raw_activity(start_time, end_time)")
    
    # AI Processed Sessions
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_start DATETIME NOT NULL,
        session_end DATETIME NOT NULL,
        duration_minutes REAL NOT NULL,
        primary_category TEXT,
        primary_project TEXT,
        apps_used TEXT,
        ai_context_summary TEXT,
        context_switches INTEGER DEFAULT 0
    )""")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_session_time ON sessions(session_start)")
    
    # Daily Summaries
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS daily_summary (
        date DATE PRIMARY KEY,
        total_hours REAL,
        deep_work_hours REAL,
        top_projects TEXT,
        longest_session_minutes INTEGER,
        productivity_score INTEGER,
        ai_reflection TEXT,
        email_sent BOOLEAN DEFAULT 0
    )""")
    
    conn.commit()
    conn.close()

def log_activity(start_time, end_time, duration_seconds, app_name, window_title, is_idle=False):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO raw_activity (start_time, end_time, duration_seconds, app_name, window_title, is_idle)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (start_time.isoformat(), end_time.isoformat(), duration_seconds, app_name, window_title, is_idle))
    conn.commit()
    conn.close()

def get_unprocessed_activities(since_time=None):
    # Returns activities that haven't been bundled into sessions yet
    # A simple approach is fetching activities later than the last session_end
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    if since_time:
        cursor.execute("SELECT * FROM raw_activity WHERE start_time > ? ORDER BY start_time ASC", (since_time.isoformat(),))
    else:
        cursor.execute("SELECT * FROM raw_activity ORDER BY start_time ASC")
    rows = cursor.fetchall()
    conn.close()
    return rows

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at:", DB_PATH)
