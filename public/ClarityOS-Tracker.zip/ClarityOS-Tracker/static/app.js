// Wait for DOM to load
document.addEventListener('DOMContentLoaded', () => {
    fetchStats();
    fetchRecentSessions();
    fetchLiveActivity();

    // Auto refresh live feed every 5 seconds
    setInterval(fetchLiveActivity, 5000);
});

// Tab Switching
function switchTab(tabId) {
    // Nav highlight
    document.querySelectorAll('.nav li').forEach(li => {
        li.classList.remove('active');
    });
    event.currentTarget.classList.add('active');

    // Pane display
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');

    // Refresh targeted data if needed
    if (tabId === 'sessions') {
        fetchRecentSessions();
    }
}

// Fetch API stats and populate Overview
async function fetchStats() {
    try {
        const res = await fetch('/api/today/stats');
        const data = await res.json();

        document.getElementById('stat-total-hours').textContent = data.total_hours + ' hrs';
        document.getElementById('stat-deep-hours').textContent = data.deep_work_hours + ' hrs';
        document.getElementById('stat-top-project').textContent = data.top_project || '--';
    } catch (e) {
        console.error('Failed to fetch stats:', e);
    }
}

// Category badge color helper 
function getCategoryClass(category) {
    if (!category) return '';
    const cat = category.toLowerCase();
    if (cat.includes('deep') || cat.includes('learning')) return 'deep';
    if (cat.includes('admin') || cat.includes('comm')) return 'admin';
    if (cat.includes('distract')) return 'distraction';
    return '';
}

// Format duration
function formatDuration(minutes) {
    if (minutes < 60) return Math.round(minutes) + 'm';
    return (minutes / 60).toFixed(1) + 'h';
}

// Format Date string
function formatTime(isoString) {
    const d = new Date(isoString + "Z"); // SQLite strings usually lack Z but are local, adjusting manually depending on saving logic
    const strictOffset = new Date(isoString); // We saved using native datetime.now
    return strictOffset.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Fetch Sessions and populate Tables
async function fetchRecentSessions() {
    try {
        const res = await fetch('/api/sessions/recent?limit=15');
        const data = await res.json();

        const tbody = document.getElementById('sessions-tbody');
        const timeline = document.getElementById('recent-overview-sessions');

        tbody.innerHTML = '';
        timeline.innerHTML = '';

        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="loading">No processed sessions yet.</td></tr>';
            timeline.innerHTML = '<div class="loading">No sessions tracked today.</div>';
            return;
        }

        data.forEach((s, index) => {
            const timeStr = `${formatTime(s.session_start)} - ${formatTime(s.session_end)}`;
            const badgeClass = getCategoryClass(s.primary_category);

            // Full Table Row
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${timeStr}</td>
                <td>${formatDuration(s.duration_minutes)}</td>
                <td><span class="badge ${badgeClass}">${s.primary_category}</span></td>
                <td><strong>${s.primary_project}</strong></td>
                <td>${s.ai_context_summary}</td>
                <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${s.apps_used}">${s.apps_used}</td>
            `;
            tbody.appendChild(tr);

            // Timeline Item (Overview) - limit to 3
            if (index < 3) {
                const item = document.createElement('div');
                item.className = 'session-item';
                item.innerHTML = `
                    <div class="time-col">
                        ${timeStr} <br>
                        <small>(${formatDuration(s.duration_minutes)})</small>
                    </div>
                    <div class="main-col">
                        <h4>${s.primary_project} <span class="badge ${badgeClass}" style="margin-left:8px; font-weight:normal;">${s.primary_category}</span></h4>
                        <p>${s.ai_context_summary}</p>
                    </div>
                `;
                timeline.appendChild(item);
            }
        });

    } catch (e) {
        console.error('Failed to fetch sessions:', e);
    }
}

// Fetch Live Feed
async function fetchLiveActivity() {
    // Only fetch if we are actually looking at the live tab to save network if desired
    // For now we just fetch to keep it simple.
    try {
        const res = await fetch('/api/live/activity?limit=30');
        const data = await res.json();

        const tbody = document.getElementById('live-tbody');
        tbody.innerHTML = '';

        data.forEach(act => {
            const tr = document.createElement('tr');
            const stateLabel = act.is_idle ? '<span class="badge distraction">Idle</span>' : '<span class="badge admin">Active</span>';

            tr.innerHTML = `
                <td>${formatTime(act.start_time)}</td>
                <td>${act.duration_seconds}s</td>
                <td>${act.app_name}</td>
                <td style="max-width:300px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${act.window_title}">${act.window_title}</td>
                <td>${stateLabel}</td>
            `;
            tbody.appendChild(tr);
        });

    } catch (e) {
        console.error('Live feed sync error:', e);
    }
}
