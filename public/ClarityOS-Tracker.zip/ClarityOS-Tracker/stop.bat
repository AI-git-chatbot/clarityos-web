@echo off
:: ============================================================
::  ClarityOS — Stop the tracker (kill background process)
:: ============================================================
echo Stopping ClarityOS tracker...

:: Kill pythonw.exe running main.py
taskkill /F /FI "IMAGENAME eq pythonw.exe" /FI "WINDOWTITLE eq *main*" >nul 2>&1

:: Broader kill in case window title doesn't match
for /f "tokens=2" %%i in ('tasklist /fi "IMAGENAME eq pythonw.exe" /fo csv /nh 2^>nul') do (
    wmic process where "ProcessId=%%~i" get CommandLine 2>nul | find "main.py" >nul
    if not errorlevel 1 taskkill /F /PID %%~i >nul 2>&1
)

echo Done. ClarityOS tracker stopped.
echo (It will restart automatically next time you log in.)
pause
