Set WshShell = CreateObject("WScript.Shell")
' Run pythonw.exe using the virtual environment so it runs invisibly
WshShell.Run chr(34) & "d:\work\woker.com\WorkTracker\venv\Scripts\pythonw.exe" & Chr(34) & " " & Chr(34) & "d:\work\woker.com\WorkTracker\main.py" & Chr(34), 0
Set WshShell = Nothing
