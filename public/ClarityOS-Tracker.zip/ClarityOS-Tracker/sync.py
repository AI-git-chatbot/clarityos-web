import urllib.request
import urllib.error
import json
import os

# ── Config loading ─────────────────────────────────────────────────────────────
# Reads API token & endpoint from config.json (written by install.bat on first setup)
# Falls back to env vars, then skips sync if neither is set.

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

def load_config():
    """Load config.json. Returns dict with api_token and api_endpoint."""
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

_config = load_config()

API_ENDPOINT = _config.get("api_endpoint") or os.environ.get("CLARITYOS_API_ENDPOINT", "https://clarityos.kvantumtech.com/api/sync")
API_TOKEN    = _config.get("api_token")    or os.environ.get("CLARITYOS_API_TOKEN", "")

# ── Sync function ──────────────────────────────────────────────────────────────

def sync_session_to_cloud(session_data):
    """
    Pushes a completed classification session to the ClarityOS SaaS backend.
    Silently skips if no API token is configured.
    """
    if not API_TOKEN:
        print("[Sync] Skipping: No API token configured. Run install.bat to set up.")
        return False

    try:
        req = urllib.request.Request(API_ENDPOINT, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {API_TOKEN}")

        json_data = json.dumps(session_data).encode("utf-8")

        with urllib.request.urlopen(req, data=json_data, timeout=10) as response:
            body = response.read().decode("utf-8")
            if response.status == 200:
                print(f"[Sync] ✓ Cloud sync successful")
                return True
            else:
                print(f"[Sync] ✗ Failed [{response.status}]: {body}")
                return False

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        print(f"[Sync] ✗ HTTP Error [{e.code}]: {body}")
        return False
    except Exception as e:
        print(f"[Sync] ✗ Error: {e}")
        return False
