import sqlite3
import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import ollama
from database import DB_PATH

# --- Configuration ---
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "office.amanchandel@gmail.com"  # The user needs to configure this
SMTP_PASS = "ivlz ytuq rgxx nhks"     # Gmail App Password (App: worktracker)
TO_EMAIL = "office.amanchandel@gmail.com"
# ---------------------

def get_sessions_for_report():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Try yesterday first; fall back to today so the user can test any time
    yesterday = datetime.datetime.now().date() - datetime.timedelta(days=1)
    today = datetime.datetime.now().date()

    for report_date in [yesterday, today]:
        start_of_day = datetime.datetime.combine(report_date, datetime.time.min).isoformat()
        end_of_day = datetime.datetime.combine(report_date, datetime.time.max).isoformat()
        cursor.execute("""
            SELECT * FROM sessions 
            WHERE session_end >= ? AND session_end <= ?
        """, (start_of_day, end_of_day))
        rows = cursor.fetchall()
        if rows:
            conn.close()
            return rows, report_date

    conn.close()
    return [], yesterday

def call_ai_summarizer(stats_text, sessions_summary):
    prompt = f"""
    You are an analytical productivity coach. Review this user's work data from yesterday:
    
    Stats:
    {stats_text}
    
    Sessions:
    {sessions_summary}
    
    Provide an analytical reflection summary. Include:
    1. Tasks Completed: What did the user actually do? (Summarize the main actions)
    2. Intentions: What was the user trying to do? (Infer their goals based on their app/window history)
    3. A brief structural overview of the day's productivity.
    
    Keep the tone factual, objective, and analytical. Do not be overly motivational.
    Format your response cleanly in HTML. Use <ul> or <ol> tags where appropriate.
    """
    try:
        response = ollama.chat(model='llama3.2', messages=[
            {'role': 'user', 'content': prompt}
        ], options={'temperature': 0.3})
        return response.message.content
    except Exception as e:
        print(f"Summarizer Error: {e}")
        return "<p>Failed to generate AI reflection due to an error.</p>"

def generate_and_send_report():
    print("Generating Daily Report...")
    sessions, report_date = get_sessions_for_report()
    
    if not sessions:
        print("No sessions found for yesterday. Skipping email.")
        return

    # Aggregate stats
    total_minutes = sum(s[3] for s in sessions)
    deep_work_minutes = sum(s[3] for s in sessions if s[4] == "Deep Work")
    total_hours = total_minutes / 60.0
    deep_work_hours = deep_work_minutes / 60.0
    
    total_context_switches = sum(s[8] for s in sessions)
    
    # Process longest session
    longest_session = max(sessions, key=lambda s: s[3], default=None)
    longest_session_mins = longest_session[3] if longest_session else 0

    # Project Breakdown
    project_times = {}
    category_times = {}
    apps_used_set = set()
    
    for s in sessions:
        proj = s[5]
        cat = s[4]
        project_times[proj] = project_times.get(proj, 0) + s[3]
        category_times[cat] = category_times.get(cat, 0) + s[3]
        
        # apps_used is a comma-separated string
        apps = [a.strip() for a in s[6].split(",")]
        apps_used_set.update(apps)

    sorted_projects = sorted(project_times.items(), key=lambda x: x[1], reverse=True)
    top_3_projects = sorted_projects[:3]
    
    # Store daily rollup in DB
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR IGNORE INTO daily_summary (date, total_hours, deep_work_hours, top_projects, longest_session_minutes, email_sent)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        report_date.isoformat(), 
        total_hours, 
        deep_work_hours, 
        ", ".join([p[0] for p in top_3_projects]), 
        longest_session_mins,
        0
    ))
    conn.commit()
    conn.close()

    # Formatting AI Prompt inputs
    stats_text = f"""
    Total Hours: {total_hours:.2f}
    Deep Work Hours: {deep_work_hours:.2f}
    Context Switches: {total_context_switches}
    Longest Focus: {longest_session_mins:.1f} mins
    Top Projects: {", ".join([f"{p[0]} ({p[1]:.1f}m)" for p in top_3_projects])}
    Categories: {", ".join([f"{c}: {m:.1f}m" for c, m in category_times.items()])}
    """
    
    session_lines = []
    for s in sessions:
        session_lines.append(f"- {s[3]:.1f}m [{s[4]}] {s[5]}: {s[7]}")
    sessions_summary = "\n".join(session_lines)

    ai_reflection = call_ai_summarizer(stats_text, sessions_summary)
    
    # Create Email Payload
    subject = f"Daily Work Summary – {report_date.strftime('%b %d, %Y')}"
    
    html_content = f"""
    <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <h2>📊 {subject}</h2>
        <hr>
        <h3>Core Metrics</h3>
        <ul>
            <li><b>Total Hours Worked:</b> {total_hours:.2f}</li>
            <li><b>Deep Work Hours:</b> {deep_work_hours:.2f}</li>
            <li><b>Longest Focus Session:</b> {longest_session_mins:.1f} mins</li>
            <li><b>Total Context Switches:</b> {total_context_switches}</li>
        </ul>
        
        <h3>Top 3 Projects</h3>
        <ol>
            {"".join([f"<li><b>{p[0]}</b> - {p[1]:.1f} mins</li>" for p in top_3_projects])}
        </ol>
        
        <h3>Category Breakdown</h3>
        <ul>
             {"".join([f"<li><b>{c}</b>: {m:.1f} mins</li>" for c, m in category_times.items()])}
        </ul>
        
        <h3>Most Used Applications</h3>
        <p>{", ".join(list(apps_used_set)[:10])}</p>
        <hr>
        <h3>🤖 AI Productivity Reflection</h3>
        <div>
            {ai_reflection}
        </div>
      </body>
    </html>
    """

    send_email(subject, html_content, report_date)

def send_email(subject, html_content, report_date):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = SMTP_USER
    msg["To"] = TO_EMAIL

    part = MIMEText(html_content, "html")
    msg.attach(part)

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USER, SMTP_PASS)
        server.sendmail(SMTP_USER, TO_EMAIL, msg.as_string())
        server.quit()
        print(f"Email sent successfully for {report_date}")
        
        # Mark as sent in DB
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE daily_summary SET email_sent = 1 WHERE date = ?", (report_date.isoformat(),))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Failed to send email: {e}")

if __name__ == "__main__":
    generate_and_send_report()
