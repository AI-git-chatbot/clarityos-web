import sqlite3
import json
import re
from datetime import datetime
import ollama
from database import DB_PATH, get_unprocessed_activities
from sync import sync_session_to_cloud

# We define a session as 15 minutes of activity roughly
SESSION_THRESHOLD_SECONDS = 15 * 60

# Only these values are valid for primary_category
VALID_CATEGORIES = {
    "Deep Work", "Admin", "Research",
    "Communication", "Learning", "General Work"
}

def _extract_json(text: str) -> dict | None:
    """
    Try multiple strategies to pull the JSON object out of `text`.
    Returns a dict on success, None on failure.
    """
    # Strategy 1: The whole text is valid JSON already
    try:
        return json.loads(text.strip())
    except Exception:
        pass

    # Strategy 2: Extract first {...} block (handles markdown code fences, extra prose, etc.)
    # Use a greedy match to handle nested quotes inside the JSON values
    match = re.search(r'\{[\s\S]*?\}', text)
    if match:
        try:
            return json.loads(match.group())
        except Exception:
            pass

    # Strategy 3: Wider greedy match in case there are nested braces
    match = re.search(r'\{[\s\S]+\}', text)
    if match:
        try:
            return json.loads(match.group())
        except Exception:
            pass

    # Strategy 4: Key-by-key extraction as last resort
    result = {}
    for key in ("primary_category", "primary_project", "ai_context_summary"):
        # Match: "key": "value"  or  key: value
        m = re.search(
            rf'["\']?{key}["\']?\s*:\s*["\']([^"\'{{}}]+)["\']',
            text, re.IGNORECASE
        )
        if m:
            result[key] = m.group(1).strip()
    return result if result else None


def call_local_ai_classifier(activities_summary, max_retries: int = 3):
    """
    Calls Ollama locally to classify a batch of activities.
    Retries up to max_retries times and uses multi-strategy JSON extraction.
    Requires ollama to be running with the `llama3.2` model.
    """
    prompt = f"""You are a work-tracking AI. Given the apps and windows a user had open, classify their work session.

ACTIVITIES:
{activities_summary}

CATEGORIES (pick exactly one):
- Deep Work      → coding, writing, designing, building (VSCode, Figma, terminals, Word docs)
- Research       → reading docs, articles, Stack Overflow, YouTube (learning-oriented)
- Communication  → email, Slack, Discord, WhatsApp, Teams, Zoom
- Admin          → file management, system settings, installs, OS tasks
- Learning       → structured courses, tutorials, documentation study
- General Work   → anything active that doesn't fit the above

INSTRUCTIONS:
- primary_project: 1-3 word tag identifying the project (e.g. "ClarityOS", "Client Email", "System Setup")
- ai_context_summary: One sentence describing what the user was doing

EXAMPLE OUTPUT (copy this exact format):
{{"primary_category": "Deep Work", "primary_project": "ClarityOS", "ai_context_summary": "User was coding the Next.js dashboard and Prisma schema."}}

Respond with ONLY the JSON object. No markdown, no explanation, no extra text."""

    fallback = {
        "primary_category": "General Work",
        "primary_project": "Unknown",
        "ai_context_summary": "Could not classify this session."
    }

    for attempt in range(1, max_retries + 1):
        try:
            response = ollama.chat(
                model='llama3.2',
                messages=[{'role': 'user', 'content': prompt}],
                options={'temperature': 0.0}  # fully deterministic
            )
            content = response.message.content.strip()
            print(f"  [AI attempt {attempt}] Raw response: {content[:200]}")

            parsed = _extract_json(content)
            if parsed is None:
                print(f"  [AI attempt {attempt}] Could not extract JSON, retrying...")
                continue

            # Validate and sanitize the category
            category = parsed.get("primary_category", "").strip()
            if category not in VALID_CATEGORIES:
                print(f"  [AI attempt {attempt}] Invalid category '{category}', defaulting to 'General Work'")
                parsed["primary_category"] = "General Work"

            # Ensure all keys are present
            parsed.setdefault("primary_project", "Unknown")
            parsed.setdefault("ai_context_summary", "No summary provided.")
            return parsed

        except Exception as e:
            print(f"  [AI attempt {attempt}] Error: {e}")

    print("  [AI] All retries exhausted — using fallback classification.")
    return fallback

def aggregate_sessions():
    """
    Aggregates raw activities from the database into sessions, calls AI, and stores the results.
    """
    print("Running Session Aggregation & Classification...")
    
    # Get the timestamp of the last processed session
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT session_end FROM sessions ORDER BY session_end DESC LIMIT 1")
    row = cursor.fetchone()
    
    since_time = None
    if row:
        since_time = datetime.fromisoformat(row[0])
        
    activities = get_unprocessed_activities(since_time)
    
    if not activities:
        print("No new activities to process.")
        conn.close()
        return

    # Group activities by 15-minute chunks for the AI
    # OR simply process all new ones as one session if they span roughly 15-30 mins
    # For a simple implementation, we'll chunk by continuous time blocks
    
    current_chunk = []
    chunk_start = datetime.fromisoformat(activities[0][1])  # start_time of first item
    
    for act in activities:
        act_id, start_str, end_str, duration, app, title, is_idle = act
        act_start = datetime.fromisoformat(start_str)
        
        # If the gap between current activity and chunk start is > session threshold, finalize chunk
        if (act_start - chunk_start).total_seconds() > SESSION_THRESHOLD_SECONDS:
            if current_chunk:
                process_chunk(current_chunk, cursor)
            current_chunk = [act]
            chunk_start = act_start
        else:
            current_chunk.append(act)
            
    # Process final chunk if it meets a minimum duration (e.g., 5 minutes)
    # or just process whatever is left
    if current_chunk:
        process_chunk(current_chunk, cursor)
        
    conn.commit()
    conn.close()
    print("Aggregation complete.")

def process_chunk(chunk, db_cursor):
    """Summarizes a chunk of activities, calls AI, and inserts into DB."""
    if not chunk:
        return
        
    chunk_start = chunk[0][1]
    chunk_end = chunk[-1][2]
    
    total_duration = sum(act[3] for act in chunk)
    context_switches = len(chunk)
    
    # Filter out extremely brief activities (< 5s) for the prompt to save tokens
    meaningful_activities = [act for act in chunk if act[3] > 5]
    if not meaningful_activities:
        meaningful_activities = chunk
        
    # Create summary for AI
    app_usage = {}
    for act in meaningful_activities:
        app = act[4]
        title = act[5]
        duration = act[3]
        if app not in app_usage:
            app_usage[app] = {"duration": 0, "titles": set()}
        app_usage[app]["duration"] += duration
        # Keep top 3 titles per app to avoid token limit explosions
        if len(app_usage[app]["titles"]) < 3:
            app_usage[app]["titles"].add(title)
            
    # Format string for prompt
    summary_lines = []
    apps_used_list = []
    for app, data in app_usage.items():
        apps_used_list.append(app)
        titles_str = ", ".join(data["titles"])
        summary_lines.append(f"- App: {app} (Total Time: {data['duration']}s)\n  Titles: {titles_str}")
        
    activities_text = "\n".join(summary_lines)
    
    # Only mark as Distraction if user was IDLE for >80% of the chunk
    idle_time = sum(act[3] for act in chunk if act[6] == 1)
    active_time = total_duration - idle_time
    if idle_time > total_duration * 0.8 or active_time < 30:  # <30s active = away
        ai_result = {
            "primary_category": "Idle",
            "primary_project": "Away",
            "ai_context_summary": "User was away from the computer."
        }
    else:
        ai_result = call_local_ai_classifier(activities_text)
        
    duration_minutes = total_duration / 60.0
    apps_used_str = ", ".join(apps_used_list)
    
    db_cursor.execute("""
        INSERT INTO sessions (session_start, session_end, duration_minutes, primary_category, primary_project, apps_used, ai_context_summary, context_switches)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        chunk_start, 
        chunk_end, 
        duration_minutes, 
        ai_result.get("primary_category", "Unknown"),
        ai_result.get("primary_project", "Unknown"),
        apps_used_str,
        ai_result.get("ai_context_summary", ""),
        context_switches
    ))
    
    # Sync to SaaS Backend
    session_data = {
        "sessionStart": chunk_start,
        "sessionEnd": chunk_end,
        "durationMinutes": duration_minutes,
        "primaryCategory": ai_result.get("primary_category", "Unknown"),
        "primaryProject": ai_result.get("primary_project", "Unknown"),
        "appsUsed": apps_used_str,
        "aiContextSummary": ai_result.get("ai_context_summary", ""),
        "contextSwitches": context_switches
    }
    sync_session_to_cloud(session_data)

if __name__ == "__main__":
    aggregate_sessions()
