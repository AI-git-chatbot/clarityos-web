import sqlite3
import datetime
from flask import Flask, jsonify, request, send_from_directory
import os
from database import DB_PATH

app = Flask(__name__, static_folder='static', static_url_path='')

def query_db(query, args=(), one=False):
    """Wrapper to query the SQLite DB and return dictionaries."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(query, args)
    rv = [dict(row) for row in cur.fetchall()]
    conn.close()
    return (rv[0] if rv else None) if one else rv

# --- API Endpoints ---

@app.route('/api/today/stats', methods=['GET'])
def get_today_stats():
    """Returns total active time, total deep work time, and top project for today."""
    today = datetime.datetime.now().date().isoformat()
    # To get accurate stats for 'today', we sum sessions that started today
    start_of_day = today + "T00:00:00"
    end_of_day = today + "T23:59:59"
    
    sessions = query_db(
        "SELECT duration_minutes, primary_category, primary_project FROM sessions WHERE session_start >= ? AND session_end <= ?", 
        [start_of_day, end_of_day]
    )
    
    total_minutes = sum(s['duration_minutes'] for s in sessions)
    deep_work_minutes = sum(s['duration_minutes'] for s in sessions if s['primary_category'] == 'Deep Work')
    
    projects = {}
    for s in sessions:
        proj = s['primary_project']
        projects[proj] = projects.get(proj, 0) + s['duration_minutes']
        
    top_project = max(projects, key=projects.get) if projects else "None"
    
    return jsonify({
        "total_hours": round(total_minutes / 60.0, 2),
        "deep_work_hours": round(deep_work_minutes / 60.0, 2),
        "top_project": top_project
    })

@app.route('/api/live/activity', methods=['GET'])
def get_live_activity():
    """Returns the last 50 raw activity logs."""
    limit = int(request.args.get('limit', 50))
    logs = query_db("SELECT start_time, duration_seconds, app_name, window_title, is_idle FROM raw_activity ORDER BY start_time DESC LIMIT ?", [limit])
    return jsonify(logs)

@app.route('/api/sessions/recent', methods=['GET'])
def get_recent_sessions():
    """Returns the AI processed sessions ordered by recency."""
    limit = int(request.args.get('limit', 20))
    sessions = query_db("SELECT * FROM sessions ORDER BY session_end DESC LIMIT ?", [limit])
    return jsonify(sessions)

# --- Frontend Serving ---

@app.route('/')
def serve_index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    # Makes the frontend accessible only on localhost
    print("Dashboard Server started on http://127.0.0.1:5000")
    app.run(host='127.0.0.1', port=5000, debug=False)
