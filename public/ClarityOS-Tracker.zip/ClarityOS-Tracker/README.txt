======================================
  ClarityOS Desktop Tracker — Setup
======================================

REQUIREMENTS
------------
- Windows 10 or 11
- Python 3.10 or newer (https://python.org/downloads)
  !! During install, check "Add Python to PATH" !!
- Ollama (for AI classification) — https://ollama.com
  After installing Ollama, open a terminal and run:
    ollama pull llama3.2

SETUP (3 steps)
---------------
1. Get your API Token
   → Go to https://clarityos.kvantumtech.com/setup
   → Sign in → copy your API Token

2. Run the installer
   → Right-click "install.bat"
   → Choose "Run as administrator"
   → Paste your API Token when prompted
   → Done!

3. That's it!
   ClarityOS will now:
   - Run silently in the background (no windows)
   - Auto-start every time you log in
   - Sync your tracked time to your dashboard

VIEW YOUR DASHBOARD
-------------------
→ https://clarityos.kvantumtech.com

STOP THE TRACKER
----------------
→ Double-click "stop.bat"
   (It will restart automatically on next login)

UNINSTALL
---------
→ Run stop.bat
→ Open Task Scheduler → delete "ClarityOS Tracker"
→ Delete this folder

TROUBLESHOOTING
---------------
- "Python not found" → Install Python and check "Add to PATH"
- Tracker not syncing → Re-run install.bat and re-enter your token
- AI not classifying → Make sure Ollama is running:
    Open terminal → type: ollama serve

======================================
